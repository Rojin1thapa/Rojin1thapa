# Rojin Thapa Portfolio Website

A responsive portfolio built with plain HTML, CSS, and JavaScript.

## Files
- `index.html` — website structure and content
- `css/style.css` — responsive styling
- `js/script.js` — mobile navigation, current year, and contact form handling
- `assets/` — place your profile photo or other assets here if you want to add them

## Run locally
1. Extract the ZIP file.
2. Open the extracted folder.
3. Double-click `index.html` to open the website in your browser.

For development, open the folder in Visual Studio Code and use the Live Server extension.

## Enable email delivery for the contact form
1. Visit https://web3forms.com/ and create an access key for `thaparojin677@gmail.com`.
2. Open `js/script.js`.
3. Replace `YOUR_ACCESS_KEY_HERE` in `WEB3FORMS_ACCESS_KEY` with your real key.
4. Save and upload the updated files to your website hosting.

Until a real key is configured, the form opens the visitor's default email app as a fallback. WhatsApp opens a prefilled chat; the visitor must press Send in WhatsApp.

## Before publishing
- Check your phone number and social links.
- Add your profile image to `assets/` and update the HTML if desired.
- Ensure your hosting points to `index.html`.
- Never publish private API keys other than the intended public form access key.
