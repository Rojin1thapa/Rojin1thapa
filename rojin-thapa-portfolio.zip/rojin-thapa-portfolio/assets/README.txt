Place optional images or other static assets in this folder.
